# -*- coding: utf-8 -*-
"""
Editor de Spyder

Este es un archivo temporal
"""

